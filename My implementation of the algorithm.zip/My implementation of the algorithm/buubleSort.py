from random import randint

def bubbleSort(array):
	for i in range(len(array)-1):
	    for j in range(len(array)-i-1):
	        if array[j] > array[j+1]:
	            array[j], array[j+1] = array[j+1], array[j]
	return array

array = [ randint(1, 99) for x in range(1111)]

print(bubbleSort(array))