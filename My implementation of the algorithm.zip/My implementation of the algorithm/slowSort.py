from random import randint

def findSmallest(array):
	smallest = array[0]
	smallestIndex = 0
	for i in range(1, len(array)):
		if array[i] < smallest:
			smallest = array[i]
			smallestIndex = i
	return smallestIndex

def slowSort(array):
	newArray = []
	for i in range(len(array)):
		smallest = findSmallest(array);
		newArray.append(array.pop(smallest))
	return newArray

array = [randint(1, 99) for x in range(1111)]

print(slowSort(array))