import random

def binarySearch(listOfNum, item):
	low = 0
	hight = len(listOfNum)-1

	while low <= hight:
		mid = int((low + hight)/2)
		guess = listOfNum[mid]
		if guess == item:
			return mid
		if guess > item:
			hight = mid - 1
		else:
			low = mid + 1
	return None


# myList = [x for x in range(0, 99999, 1)]
myList = [2, 3, 4 ,5 ,6, 8, 99, 135, 524, 2432, 124231, 1312312 ,131312321]
print (binarySearch(myList, 524))
