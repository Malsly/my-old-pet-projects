from random import randint

def qSort(array):
	if len(array) < 2:
		return array
	else:
		midNum = array[1]
		less = [i for i in array[1:] if i <= midNum]
		greater = [i for i in array[1:] if i > midNum]
		return qSort(less) + [midNum] + qSort(greater)

array = [randint(1, 99) for x in range(1111)]

print (qSort(array))