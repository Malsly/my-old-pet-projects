vertices = ('A', 'B', 'C', 'D')

matrix = {
    'B': {'A': 5, 'D': 5},
    'A': {'B': 4, 'C': 7, 'D': 12},
    'D': {'B': 5, 'C': 3, 'A': 12},
    'C': {'A': 7, 'D': 3}
    }

notVisited = {node: None for node in vertices}
visited = {}
current = 'A'
currentDistance = 0
notVisited[current] = currentDistance

while True:
    for neighbour, distance in matrix[current].items():
        if neighbour not in notVisited: continue
        newDistance = currentDistance + distance
        if notVisited[neighbour] is None or notVisited[neighbour] > newDistance:
            notVisited[neighbour] = newDistance
    visited[current] = currentDistance
    del notVisited[current]
    if not notVisited: break
    candidates = [node for node in notVisited.items() if node[1]]
    current, currentDistance = sorted(candidates, key = lambda x: x[1])[0]

print(visited)