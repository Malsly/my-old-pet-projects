// Connected Libraries
const express = require("express"),
      app = express(),
      log4js = require("log4js"),
      http = require("http").Server(app),
      io = require("socket.io")(http),
      sqlite3 = require("sqlite3").verbose();

// The port or domain is required
let port = process.env.PORT || 3000;

//Configure logging
log4js.configure({
  appenders: { chat: { type: "file", filename: __dirname + "/database_and_logs/chat.log" } },
  categories: { default: { appenders: ["chat"], level: "error" } }
});

const logger = log4js.getLogger("chat");
logger.level = "debug";

// create parser json
const jsonParser = express.json();

//Get our html page and paste
app.get("/", (req, res) => {
  res.sendFile(__dirname + "/public/index.html");
});

//Download all static files
app.use(express.static(__dirname + "/public"));

//Web sockets and events for them
io.on("connection", (socket) => {

  //obj for user
  let user = new User(socket.id, null, null, true, false);

  //form for regestration
  app.post("/register", jsonParser, (req, res) => {
    if(!req.body) return res.sendStatus(400);
    res.json(req.body); 
  });

  //login user event
  socket.on("login_user", (userData)=>{
    default_user_status();
    user.name = userData.userName;
    user.pass = userData.userPass;
    login_user(userData);
  });

  //sign in user event
  socket.on("sign_in_user", (userData)=>{
    default_user_status();
    user.name = userData.userName;
    user.pass = userData.userPass;
    sign_in_user(userData);
  });

  //anonim user event
  socket.on("login_anon", ()=>{
    default_user_status();
    socket.emit("clear_authorization_incomplete");
    user.name = `User => ${(user.id).toString().substr(1,5)}`,
    user.isConnect = true;
    socket.broadcast.emit("new_user", user.name);
    socket.emit("hello_user", user.name);
    logger.debug(`Anonim user ${user.name} connect`);
  });

  //Massage to all clients evt
  socket.on("message", (msg) => {
    if(user.isConnect){
      io.sockets.emit("message_to_clients", msg, user.name);
    }
  });
  
  //Event for disconnect user  
  socket.on("disconnect", () => {
    if(user.isConnect){
      io.emit("user disconnected");
      socket.broadcast.emit("disconnect_user", user.name);
      logger.debug(`User ${user.name} disconnect`);
    }
    user.isAnonim == false ? close_db(users_db) : true;
  });

  //create obj for db
  const users_db = new sqlite3.Database(__dirname + "/database_and_logs/users.db", sqlite3.OPEN_READWRITE, (err)=>{
      if(err){
        logger.debug(`Error with open usrers database => ${err}`);
        return console.log(err.message);
      };
      logger.debug("Database users open");
    });

  //login user
  function login_user(userData){
    users_db.run(`INSERT INTO users(user_name, password) VALUES ("${user.name}", "${user.pass}")`, (err, res) =>{
      if (err) {
        console.log(err.message);
        logger.debug(`Error with write in db usrers => ${err}`);
        socket.emit("authorization_incomplete");
        return false;
      }
      change_user_status(userData);
      user.greeteng_users(socket);
      socket.emit("clear_authorization_incomplete");    
      logger.debug(`User ${user.name} registry`);
      return true
    });
  }

  //sign in user
  function sign_in_user(userData){
    users_db.get(`SELECT user_name, password FROM users WHERE user_name = "${user.name}" AND password = "${user.pass}"`, (err, res) =>{
      if (err) {
        console.log(err.message);
        logger.debug(`Error with write in db usrers => ${err}`);
        return false;
      }
      if(res != undefined){
        change_user_status(userData);
        user.greeteng_users(socket);    
        socket.emit("clear_authorization_incomplete");
        logger.debug(`User ${user.name} registry`);
        return true
      }
      socket.emit("authorization_incomplete");
    });
  }

  //close database
  function close_db(users_db) {
    users_db.close((err) => {
      if (err) {
        return console.error(err.message);
        logger.debug(`Error with close usrers database => ${err}`);
      }
    });
    logger.debug("Database users close");
  }

  //set status of connected user
  function change_user_status(userData) { 
    user.isConnect = true;
    user.isAnonim = false;
    user.name = userData.userName;
    user.pass = userData.userPass;
  }

  //set default user status
  function default_user_status() {  
    user.name = null,
    user.pass = null,
    user.isAnonim = true,
    user.isConnect = false
  }

});

//Start HTTP server
http.listen(port, () => {
  logger.debug(`Server started on port ${port}`);
  console.log(`listening on *: ${port}`);
});

class User { 
  constructor(id, name, pass, isAnonim, isConnect) {
    this.id = id;
    this.name = name;
    this.pass = pass;
    this.isAnonim = isAnonim;
    this.isConnect = isConnect;
  }
  
  //say hello to users
  greeteng_users(socket) {  
    //Send to all sockets without client "User ${userName} connect"
    socket.broadcast.emit("new_user", this.name);
    //Send to client "You"r username is ${userName}"
    socket.emit("hello_user", this.name);
  }

}
