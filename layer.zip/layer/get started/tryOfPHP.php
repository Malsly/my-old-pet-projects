<?php

$connection = mysqli_connect('127.0.0.1', 'root', '', 'blogDb');

if($connection == false){
	echo "Not connect";
	echo mysqli_connect_error();
	exit();
}

$articles_category = mysqli_query($connection, "SELECT * FROM `articles_category`");
$articles = mysqli_query($connection, "SELECT * FROM `articles`");

if(mysqli_num_rows($articles_category) == 0){
	echo "Categories not founded";
} else{ echo "Catedories find : " . mysqli_num_rows($articles_category); }


?>


<ul>
	<?php
		while( ($cat = mysqli_fetch_assoc($articles_category)) )
		{
			$articles_count = mysqli_query($connection, "SELECT COUNT('id') AS `total_count` FROM `articles` WHERE `categorie_id` = " . $cat['id']);
			$articles_count_result = mysqli_fetch_assoc($articles_count);
			echo '<li>' . $cat['title'] . '(' . $articles_count_result['total_count'] . ')</li>';
		}
	?>
</ul>


<ul>
	<?php
		while( ($cat = mysqli_fetch_assoc($articles)) )
		{
			echo '<li>' . '<pre >' . $cat['text'] . '</pre>' . '</li>';
		}
	?>
</ul>

<?php

mysql_close($connection);

?>і