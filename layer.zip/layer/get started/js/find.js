$(document).ready(function(){
  $("#submit").click(function(){
  var term = "";
  var n = "0";
  $('body').removeHighlight();
  $("p.results").hide().empty();
  term = $('#term').attr('value');
  if($('#term').val() == ""){
  $("p.results").fadeIn().append("Enter search query in field above");
  return false;
  }else{
  $('.main').highlight( term );
  n = $("span.highlight").length;
  if(n == 0){
  $("p.results").fadeIn().append("Not found");
  }else{
  $("p.results").fadeIn().append('Found: '+n+' matches.');
  }
  return false;
  }
  });      
});