//requestAnimationFrameCrossbrowser
(function () {
    var requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;
    window.requestAnimationFrame = requestAnimationFrame;
})();
//canvas attribute and player obj
var canvas = document.getElementById("canvas"),
    ctx = canvas.getContext("2d"),
    width = 1500,
    height = 730,
    player = {
        x: 3,
        y: height - 40,
        width: 20,
        height: 20,
        speed: 5,
        speedX: 0,
        speedY: 0,
        jumping: false,
        grounded: false
    },
    keys = [],
    slovly = 0.9,
    gravity = 0.4;

var obst = [];

// create obst
obst.push({ x: 1200, y: 650, width: 100, height: 10 } ,{ x: 0, y: 0, width: 0.1, height: height }, { x: 0, y: height, width: width, height: 50}, { x: width, y: 0, width: 1, height: height }, { x: 650, y: 490, width: 10, height: 10 }, { x: 650, y: 560, width: 10, height: 10 }, { x: 650, y: 620, width: 10, height: 10 }, { x: 550, y: 620, width: 10, height: 10 }, { x: 650, y: 400, width: 5, height: 300 },  { x: width-25, y: height-500, width: 25, height: 5 }, { x: 1250, y: 350, width: 5, height: 25 }, { x: 1050, y: 350, width: 5, height: 25 }, { x: 850, y: 400, width: 5, height: 55 }, { x: 450, y: 400, width: 5, height: height - 300 }, { x: 350, y: 400, width: 50, height: 50 }, { x: 410, y: 300, width: 50, height: 50 }, { x: 110, y: 560, width: 50, height: 50 }, { x: 110, y: 460, width: 50, height: 50 }, { x: 270, y: 660, width: 50, height: 50 }, { x: 300, y: 660, width: 50, height: 50 } );

// canvas width/height
canvas.width = width;
canvas.height = height;

function update() {
    // check keys
    let keyA = keys[65];
    let keyD = keys[68];
    let keyW = keys[87];
    let keyS = keys[83];

    let leftKey = keys[37];
    let rightKey = keys[39];
    let downKey = keys[38];
    let upKey = keys[40];

    let space = keys[32]

    if (downKey || keyW || space) {
        // check jumps
        if (!player.jumping && player.grounded) {
            player.jumping = true;
            player.grounded = false;
            player.speedY = -player.speed * 2;
        }
    }
    if (rightKey || keyD) {
        // to right side
        if (player.speedX < player.speed) {
            player.speedX += 1;
        }
    }
    if (leftKey || keyA) {
        // to left side
        if (player.speedX > -player.speed) {
            player.speedX--;
        }
    }

    player.speedX *= slovly;
    player.speedY += gravity;

    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = "black";
    ctx.beginPath();

    player.grounded = false;

    for (var i = 0; i < obst.length; i++) {
        ctx.rect(obst[i].x, obst[i].y, obst[i].width, obst[i].height);

        var dir = vectCheck(player, obst[i]);

        if (dir === "left" || dir === "right") {
            player.speedX = 0;
            player.jumping = false;
        } else if (dir === "bottom") {
            player.grounded = true;
            player.jumping = false;
        } else if (dir === "top") {
            player.speedY *= -1;
        }

    }

    if(player.grounded){
         player.speedY = 0;
    }

    player.x += player.speedX;
    player.y += player.speedY;

    ctx.fill();
    ctx.fillStyle = "green";
    ctx.fillRect(player.x, player.y, player.width, player.height);

    requestAnimationFrame(update);
}

function vectCheck(obj1, obj2) {
        var vectX = (obj1.x + (obj1.width / 2)) - (obj2.x + (obj2.width / 2)),
        vectY = (obj1.y + (obj1.height / 2)) - (obj2.y + (obj2.height / 2)),
        // add the half widths and half heights of the objects
        halfWidths = (obj1.width / 2) + (obj2.width / 2),
        halfHeights = (obj1.height / 2) + (obj2.height / 2),
        colDir = null;

    // if vect less than halfSizes check side
    if (Math.abs(vectX) < halfWidths && Math.abs(vectY) < halfHeights) {
        //what side touch (top, bottom, left, or right)
        var distanceX = halfWidths - Math.abs(vectX),
            distanceY = halfHeights - Math.abs(vectY);

        if (distanceX >= distanceY) {
            if (vectY > 0) {
                colDir = "top";
                obj1.y += distanceY;
            } else {
                colDir = "bottom";
                obj1.y -= distanceY;
            }
        } else {
            if (vectX > 0) {
                colDir = "left";
                obj1.x += distanceX;
            } else {
                colDir = "right";
                obj1.x -= distanceX;
            }
        }
    }
    return colDir;
}

document.body.addEventListener("keydown", function (e) {
    keys[e.keyCode] = true;
});

document.body.addEventListener("keyup", function (e) {
    keys[e.keyCode] = false;
});

window.addEventListener("load", function () {
    update();
});
