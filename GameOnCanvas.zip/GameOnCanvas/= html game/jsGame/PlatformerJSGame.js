                                                                                   /*CREATE OBJECTS*/
function startGame() { 
    globalEnemy = new component(10, 10, 'jsGame/imgForJS/witch.png', 430, 120, "image");                
    globalHero = new component(15, 15, "jsGame/imgForJS/boy.png", 0, 250, "image");    
    globalBackground = new component(480, 270, "jsGame/imgForJS/street.jpg", 0, 0, "image")                    
                                                                                /*OBSTSCLE CREATE*/
    leftBorder = new component(1, 2700, "black", -1, 0);
    rightBorder = new component(1, 2700, "black", 480, 0);               
    topBorder = new component(1480, 1, "black", 0, -1);                
    
    hor1 =  new component(20, 5, "jsGame/imgForJS/grass.png", 30, 248, "image");
    ver1 =  new component(5, 50, "jsGame/imgForJS/grass.png", 50, 200, "image");
    ver2 =  new component(5, 50, "jsGame/imgForJS/grass.png", 100, 200, "image");
    hor2 =  new component(30, 5, "jsGame/imgForJS/grass.png", 100, 230, "image");
    hor3 =  new component(40, 5, "jsGame/imgForJS/grass.png", 170, 210, "image");
    hor4 =  new component(40, 5, "jsGame/imgForJS/grass.png", 270, 190, "image");
    hor5 =  new component(40, 5, "jsGame/imgForJS/grass.png", 290, 130, "image");    
    hor6 =  new component(20, 5, "jsGame/imgForJS/grass.png", 0, 270, "image");
    
    cage =  new component(20, 20, "jsGame/imgForJS/cage.jpg", 0, 250, "image");
    
     
    myGameArea.start();
}
 
 

                                                                                /*GAME ARENA*/
let myGameArea = {
    canvas : document.createElement("canvas"),
    start : function() {
        this.canvas.width = 480;
        this.canvas.height = 270; 
        this.ctx = this.canvas.getContext("2d");
        document.body.insertBefore(this.canvas, document.body.childNodes[0]);
        this.interval = setInterval(updateGameArea, 20);
        window.addEventListener('keydown', function (e) {
            myGameArea.keys = (myGameArea.keys || []);
            myGameArea.keys[e.keyCode] = (e.type == "keydown");
        }) 
        window.addEventListener('keyup', function (e) {
            myGameArea.keys[e.keyCode] = (e.type == "keydown");            
        })
    }, 
    clear : function(){
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
}

                                                                            /*Function FOR CREATE OBJECTS*/
function component(width, height, color, x, y, type) {
    this.type = type;
    if (type == "image") {
        this.image = new Image();
        this.image.src = color;
    }
    this.width = width;
    this.height = height;
    this.speedX = 0;
    this.speedY = 0;    
    this.gravity = 0;
    this.gravitySpeed = 0;
    this.x = x;
    this.y = y;  
    
    this.update = function() {
        ctx = myGameArea.ctx;
        if (type == "image") {
            ctx.drawImage(this.image, this.x, this.y, this.width, this.height);
        } else {
            ctx.fillStyle = color;
            ctx.fillRect(this.x, this.y, this.width, this.height);
        }
    }
    
    this.newPos = function() {
        this.gravitySpeed += this.gravity;
        this.x += this.speedX;
        this.y += this.speedY + this.gravitySpeed;
        this.hitBottom();
    }
    
    this.hitBottom = function() {
        let rockBottom = myGameArea.canvas.height - this.height;
        if (this.y > rockBottom) {
            this.y = rockBottom;
        }
    }
    
    this.crashWith = function(otherobj) {
        let myleft = this.x;
        let myright = this.x + (this.width);
        let mytop = this.y;
        let mybottom = this.y + (this.height);
        let otherleft = otherobj.x;
        let otherright = otherobj.x + (otherobj.width);
        let othertop = otherobj.y;
        let otherbottom = otherobj.y + (otherobj.height);
        let crash = true;
        if ((mybottom < othertop) ||
               (mytop > otherbottom) ||
               (myright < otherleft) ||
               (myleft > otherright)) {
           crash = false;
        }
        return crash;
    }
    
    this.fallOn = function(otherobj) {
        let keyA = myGameArea.keys && myGameArea.keys[65];
        let keyD = myGameArea.keys && myGameArea.keys[68];
        let keyW = myGameArea.keys && myGameArea.keys[87];
        let keyS = myGameArea.keys && myGameArea.keys[83];
        let myleft = this.x;
        let myright = this.x + (this.width);
        let mybottom = this.y + (this.height);
        let otherleft = otherobj.x;
        let otherright = otherobj.x + (otherobj.width);
        let othertop = otherobj.y;
        let otherbottom = otherobj.y + (otherobj.height);
        if(keyD && mybottom >= othertop - 5 && myleft  > otherright ){
          window.setTimeout(function() {globalHero.gravitySpeed = 6;}, 0);   
        }
        if(keyA && mybottom >= othertop - 5 && myright < otherleft){
          window.setTimeout(function() {globalHero.gravitySpeed = 6;}, 0);
        }
        if (mybottom <= othertop && mybottom >= othertop - 5 && myright - 1 >= otherleft && myleft + 1 <= otherright ) {
          globalHero.gravitySpeed = 0;
          if (keyW || keyW && keyA) {  
          globalHero.gravitySpeed = -6;

          }
          if(keyS){
            globalHero.gravitySpeed = 6;
          }
        }
    }

    this.across = function(otherobj) {
        let keyA = myGameArea.keys && myGameArea.keys[65];
        let keyD = myGameArea.keys && myGameArea.keys[68];
        let myleft = this.x;
        let myright = this.x + (this.width);
        let mybottom = this.y + (this.height);
        let otherleft = otherobj.x;
        let otherright = otherobj.x + (otherobj.width);
        let othertop = otherobj.y;
        let otherbottom = otherobj.y + (otherobj.height);

        /*if(keyD && myright <= otherleft && myright >= otherleft-2 && mybottom <= otherbottom && mytop >= othertop){
          globalHero.speedX = 0;
        }*//*SKALOLAZ*/

        /*if (this.crashWith(otherobj) && myright > otherleft && myright < otherleft ) {
        if (keyA) {globalHero.speedX = 0; }
        if (keyD) {globalHero.speedX = -3.2; }
        }*//*Prohod skvoz*/

        this.fallOn(otherobj);

        if (this.crashWith(otherobj) && myleft < otherright && myleft >= otherright ) {
        if (keyA) {globalHero.speedX = 0; }
        if (keyD) {globalHero.speedX = 3.2; }
        }

        if (this.crashWith(otherobj) && myright > otherleft && myright >= otherleft  ) {
        if (keyA) {globalHero.speedX = 0; }
        if (keyD) {globalHero.speedX = 3.2; }
        }
    }
}

function vectCheck(obj1, obj2) {
        var vectX = (obj1.x + (obj1.width / 2)) - (obj2.x + (obj2.width / 2)),
        vectY = (obj1.y + (obj1.height / 2)) - (obj2.y + (obj2.height / 2)),
        // add the half widths and half heights of the objects
        halfWidths = (obj1.width / 2) + (obj2.width / 2),
        halfHeights = (obj1.height / 2) + (obj2.height / 2),
        colDir = null;

    // if vect less than halfSizes check side 
    if (Math.abs(vectX) < halfWidths && Math.abs(vectY) < halfHeights) {
        //what side touch (top, bottom, left, or right) 
        var distanceX = halfWidths - Math.abs(vectX),
            distanceY = halfHeights - Math.abs(vectY);
  
        if (distanceX >= distanceY) {
            if (vectY > 0) {
                colDir = "top";
                obj1.y += distanceY;
            } else {
                colDir = "bottom";
                obj1.y -= distanceY;
            }
        } else {
            if (vectX > 0) {
                colDir = "left";
                obj1.x += distanceX;
            } else {
                colDir = "right";
                obj1.x -= distanceX;
            }
        }
    }
    return colDir;
}
                                                                                /*UPDATING GAME ARENA*/
function updateGameArea() {
                                                                                /*SHORT KEY*/

    let keyA = myGameArea.keys && myGameArea.keys[65];
    let keyD = myGameArea.keys && myGameArea.keys[68];
    let keyW = myGameArea.keys && myGameArea.keys[87];
    let keyS = myGameArea.keys && myGameArea.keys[83];
    
    let leftKey = myGameArea.keys && myGameArea.keys[37];
    let rightKey = myGameArea.keys && myGameArea.keys[39];
    let downKey = myGameArea.keys && myGameArea.keys[38];
    let upKey = myGameArea.keys && myGameArea.keys[40];
    

    
    
                                                                                  /*MOVING*/   
    globalHero.speedX = 0;
    globalHero.speedY = 0;  
    globalEnemy.speedX = 0;
    globalEnemy.speedY = 0;  
    
    if (keyA) {globalHero.speedX = -2.5; }
    if (keyD) {globalHero.speedX = 2.5; }
    if (keyW) {  
      window.setTimeout(function() {globalHero.gravitySpeed = -6}, 0);      
      window.setTimeout(function() {globalHero.gravitySpeed = 6}, 250);
    }
   
    if (leftKey) {globalEnemy.speedX = -3.2; }
    if (rightKey) {globalEnemy.speedX = 2.2; }
    if (downKey) {globalEnemy.speedY = -3.2; }
    if (upKey) {globalEnemy.speedY = 3.2; }
    
                                                                                  /*ENEMY CRASH*/  
    if (globalHero.crashWith(globalEnemy)) {
        myGameArea.stop();
        myGameArea.start();
    }
                                                                                /*BORDER CRASH HERO*/
    if (globalHero.crashWith(leftBorder)) {
      if (keyA) {globalHero.speedX = 0; }
    }
    if (globalHero.crashWith(rightBorder)) {
      if (keyD) {globalHero.speedX = 0; }
    }

    if (globalHero.crashWith(ver1)) {
      if (keyD && keyA) {globalHero.speedX = 0; }
    }
    
    
    if (globalEnemy.crashWith(leftBorder)) {
        if (leftKey) {globalEnemy.speedX = 0; }
    }
    if (globalEnemy.crashWith(rightBorder)) {
      if (rightKey) {globalEnemy.speedX = 0; }
    }
    if (globalEnemy.crashWith(topBorder)) {
        if (downKey) {globalEnemy.speedY = 0; }
    } 
    
    arrayOfAcross=[hor1, hor2, hor3, hor4, hor5, hor6, ver2, ver1];
    /*for(let i in arrayOfAcross){
        globalHero.across(arrayOfAcross[i]);
    }*/
    for (var i = 0; i < arrayOfAcross.length; i++) {
        arrayOfAcross[i].update();
        
        var dir = vectCheck(globalHero, arrayOfAcross[i]);

        if (dir === "left" || dir === "right") {
            globalHero.speedX = 0;
            globalHero.jumping = false;
        } else if (dir === "bottom") {
            globalHero.grounded = true;
            globalHero.jumping = false;
        } else if (dir === "top") {
            globalHero.speedY *= -1;
        }

    }
    
                                                                                                /*UPDATING*/
    myGameArea.clear();
    globalBackground.update();
    
    globalHero.newPos();    
    globalHero.update();
    
    globalEnemy.newPos();    
    globalEnemy.update();
                                                                                                  /*OBSTSCLE INIT*/
    
    arrayOfUpdate=[hor1, hor2, hor3, hor4, hor5, hor6, ver2, ver1, cage, leftBorder, rightBorder, topBorder];

    for(let i in arrayOfUpdate){
        arrayOfUpdate[i].update();
    }

} 




/*
 window.setTimeout(function() {}, 0);     

Каличество итераций == каличество пикселей. При помощи цикла
сделать массив всех обектов и обновлять их через фор ин
почитать про мультипоточность*/